package bg.unisofia.fmi.salesman;

import java.util.ArrayList;
import java.util.Collections;

public class TravellingSalesman {
	
	private final static int CITIES = 7;
	private final static int POPULATION_COUNT = 100;
	private final static int EPOCH_COUNT = 100;
	private final static double MUTATION_RATE = 0.05;
	private final static int ELITISM_RATE = 10;
	
	public static Individual crossover(Individual parent1, Individual parent2) {
        Individual child = new Individual();
        
        int startPos = (int) (Math.random() * parent1.numberOfCities());
        int endPos = (int) (Math.random() * parent1.numberOfCities());

        for (int i = 0; i < child.numberOfCities(); i++) {
            if (startPos < endPos && i > startPos && i < endPos) {
                child.setCity(i, parent1.getCity(i));
            }
            else if (startPos > endPos) {
                if (!(i < startPos && i > endPos)) {
                    child.setCity(i, parent1.getCity(i));
                }
            }
        }
        for (int i = 0; i < parent2.numberOfCities(); i++) {
            if (!child.containsCity(parent2.getCity(i))) {
                for (int ii = 0; ii < child.numberOfCities(); ii++) {
                    if (child.getCity(ii) == null) {
                        child.setCity(ii, parent2.getCity(i));
                        break;
                    }
                }
            }
        }
        return child;
        }
	
	private static void mutate(Individual individual) {
        for(int indPos1=0; indPos1 < individual.numberOfCities(); indPos1++){
            if(Math.random() < MUTATION_RATE){
                int indPos2 = (int) (individual.numberOfCities() * Math.random());
                City city1 = individual.getCity(indPos1);
                City city2 = individual.getCity(indPos2);
                individual.setCity(indPos2, city1);
                individual.setCity(indPos1, city2);
            }
        }
    }
	
	public static Population evolvePopulation(Population population) {
		Population newPopulation = new Population(population.getPopulationSize());

		ArrayList<Individual> pop = new ArrayList<Individual>();
        Collections.copy(population.getPopulation(), pop);
		Collections.sort(pop);
        ArrayList<Individual> fittest = new ArrayList<Individual>;
        fittest = pop.subList(0, ELITISM_RATE -1);

        for (int i = ELITISM_RATE; i < newPopulation.getPopulationSize(); i++) {
            Individual parent1 = fittest.get(i);
            Individual parent2 = fittest.get(i+1);
            Individual child = crossover(parent1, parent2);
            newPopulation.addIndividual(i, child);
        }

        for (int i = ELITISM_RATE; i < newPopulation.getPopulationSize(); i++) {
            mutate(newPopulation.getIndividual(i));
        }

        return newPopulation;
    }
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
