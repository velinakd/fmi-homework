package bg.unisofia.fmi.salesman;

import java.util.ArrayList;

public class Population {
	public ArrayList<Individual> population = new ArrayList<Individual>();
	public int populationSize;
	
	public Population(int populationSize) {
		this.populationSize = populationSize;
		for (int i = 0; i < populationSize; i++) {
            Individual newIndividual = new Individual();
            newIndividual.generateIndividual();
            population.add(newIndividual);
        }
	}
	
	public ArrayList<Individual> getPopulation() {
		return population;
	}
	
	public int getPopulationSize() {
		return populationSize;
	}
	
	public Individual getIndividual(int index) {
		return population.get(index);
	}
	
	public void addIndividual(int index, Individual ind) {
		population.add(ind);
	}
	
}
