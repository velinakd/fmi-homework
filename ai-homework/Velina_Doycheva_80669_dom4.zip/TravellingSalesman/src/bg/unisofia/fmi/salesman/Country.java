package bg.unisofia.fmi.salesman;

import java.util.ArrayList;

public class Country {
		private static int numberOfCities;
	    private static ArrayList<City> cities = new ArrayList<City>();

	    public Country(int n) {
	    	numberOfCities = n;
	    	for(int i=0; i<numberOfCities; i++) {
	    		cities.add(new City());
	    	}
	    }
	    
	    public static int getNumberOfCities(){
	        return numberOfCities;
	    }
	    
	    public static City getCity(int index){
	        return (City)cities.get(index);
	    }
	    
	    

}
